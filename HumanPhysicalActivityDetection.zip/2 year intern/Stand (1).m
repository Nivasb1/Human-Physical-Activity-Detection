function [b]=Stand(x,y,z)
sta=0;b=0;
for i=1:length(y)
 if(y(i)>=8&&y(i)<10)
  sta=sta+1;
 end
 
end
if(sta>length(y)*0.9)
    b=1;
end
end