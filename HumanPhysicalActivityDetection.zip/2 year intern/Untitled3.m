fileID = fopen('up1.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x=C{1};y=C{2};z=C{3};



fileID = fopen('down2.txt');

C= textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x1=C{1};y1=C{2};z1=C{3};



fileID = fopen('walkimg.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x2=C{1};y2=C{2};z2=C{3};



fileID = fopen('acc.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x3=C{1};y3=C{2};z3=C{3};


fileID = fopen('sitting.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x4=C{1};y4=C{2};z4=C{3};


fileID = fopen('run.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x5=C{1};y5=C{2};z5=C{3};



 k=1;
  for j=1:5:length(z)-40
  variance(k)=var(y(j:j+40));
  time(k)=TimeBnPeaks(y(j:j+40),15);
  SMA(k)=sma(x(j:j+40),y(j:j+40),z(j:j+40));
  SMV(k)=smv(x(j:j+40),y(j:j+40),z(j:j+40));
k=k+1;
  end


 


k=1;
  for j=1:5:length(z1)-40
  variance1(k)=var(y1(j:j+40));
  time1(k)=TimeBnPeaks(y1(j:j+40),15);
  SMA1(k)=sma(x1(j:j+40),y1(j:j+40),z1(j:j+40));
  SMV1(k)=smv(x1(j:j+40),y1(j:j+40),z1(j:j+40));
k=k+1;
  end


 k=1;
  for j=1:5:length(z2)-40
  variance2(k)=var(y2(j:j+40));
  time2(k)=TimeBnPeaks(y2(j:j+40),15);
  SMA2(k)=sma(x2(j:j+40),y2(j:j+40),z2(j:j+40));
  SMV2(k)=smv(x2(j:j+40),y2(j:j+40),z2(j:j+40));
k=k+1;
  end
 







k=1;
  for j=1:5:length(z3)-40
  variance3(k)=var(y3(j:j+40));
  time3(k)=TimeBnPeaks(y3(j:j+40),15);
  SMA3(k)=sma(x3(j:j+40),y3(j:j+40),z3(j:j+40));
  SMV3(k)=smv(x3(j:j+40),y3(j:j+40),z3(j:j+40));
k=k+1;
  end



 k=1;
  for j=1:5:length(z4)-40
  variance4(k)=var(y4(j:j+40));
  time4(k)=TimeBnPeaks(y4(j:j+40),15);
  SMA4(k)=sma(x4(j:j+40),y4(j:j+40),z4(j:j+40));
  SMV4(k)=smv(x4(j:j+40),y4(j:j+40),z4(j:j+40));
k=k+1;
  end


 k=1;
  for j=1:5:length(z5)-40
  variance5(k)=var(y5(j:j+40));
  time5(k)=TimeBnPeaks(y5(j:j+40),15);
  SMA5(k)=sma(x5(j:j+40),y5(j:j+40),z5(j:j+40));
  SMV5(k)=smv(x5(j:j+40),y5(j:j+40),z5(j:j+40));
k=k+1;
  end

figure;
x=1:length(variance);
scatter(x,variance,'g','filled');hold on;axis tight;
x=1:length(variance1);
scatter(x,variance1,'b','filled');hold on;axis tight;
x=1:length(variance2);
scatter(x,variance2,'y','filled');hold on;axis tight;
x=1:length(variance3);
scatter(x,variance3,'r','filled');hold on;axis tight;
x=1:length(variance4);
scatter(x,variance4,'p','filled');hold on;axis tight;
x=1:length(variance5);
scatter(x,variance5,'o','filled');hold on;axis tight;
legend('up','down','walking','standing','sitting','running');
title('variance');




figure;

x=1:length(SMA);
scatter(x,SMA,'g','filled');hold on;axis tight;
x=1:length(SMA1);
scatter(x,SMA1,'b','filled');hold on;axis tight;
x=1:length(SMA2);
scatter(x,SMA2,'y','filled');hold on;axis tight;
x=1:length(SMA3);
scatter(x,SMA3,'r','filled');hold on;axis tight;
x=1:length(SMA4);
scatter(x,SMA4,'p','filled');hold on;axis tight;
x=1:length(SMA5);
scatter(x,SMA5,'o','filled');hold on;axis tight;
legend('up','down','walking','standing','sitting','running');
title('SMA');

figure;

x=1:length(SMV);
scatter(x,SMV,'g','filled');hold on;axis tight;
x=1:length(SMV1);
scatter(x,SMV1,'b','filled');hold on;axis tight;
x=1:length(SMV2);
scatter(x,SMV2,'y','filled');hold on;axis tight;
x=1:length(SMV3);
scatter(x,SMV3,'r','filled');hold on;axis tight;
x=1:length(SMV4);
scatter(x,SMV4,'p','filled');hold on;axis tight;
x=1:length(SMV5);
scatter(x,SMV5,'o','filled');hold on;axis tight;
legend('up','down','walking','standing','sitting','running');
title('SMV');

figure;

x=1:length(time);
scatter(x,time,'g','filled');hold on;axis tight;
x=1:length(time1);
scatter(x,time1,'b','filled');hold on;axis tight;
x=1:length(time2);
scatter(x,time2,'y','filled');hold on;axis tight;
x=1:length(time3);
scatter(x,time3,'r','filled');hold on;axis tight;
x=1:length(time4);
scatter(x,time4,'p','filled');hold on;axis tight;
x=1:length(time5);
scatter(x,time5,'o','filled');hold on;axis tight;
legend('up','down','walking','standing','sitting','running');
title('time between peaks');