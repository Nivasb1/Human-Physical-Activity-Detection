function [a] =Sit(x,y,z)
sit=0;a=0;
for i=1:length(z)
 if(z(i)>=8&&z(i)<10)
  sit=sit+1;
 end
 
end
if sit>(length(z)*0.9)
    a=1;
end
end
