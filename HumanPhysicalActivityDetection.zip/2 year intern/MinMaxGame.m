function [t]=MinMaxGame(x,a,k)
t=0;
 if a==0
     for i=1:length(x)
         if x(i)<k
             t=t+1;
         end
     end
 else
     for i=1:length(x)
         if x(i)>k
             t=t+1;
         end
     end
 end

         