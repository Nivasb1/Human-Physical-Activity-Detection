fileID = fopen('down1.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x=C{1};y=C{2};z=C{3};
% x=x(200:1200);
 %y=y(200:1200);
 %z=z(200:1200);
figure;

% title('Sitting Action');
subplot(3,1,1);
plot(x,'r');
grid on ;axis tight;
xlabel('Time');
ylabel('Accelerometer x Reading');
subplot(3,1,2);
plot(y,'g');
grid on ;axis tight;
xlabel('Time');
ylabel('Accelerometer y Reading');
subplot(3,1,3);
plot(z,'b');
grid on ;axis tight;
xlabel('Time');
ylabel('Accelerometer z Reading');
thr_xmax=MinMaxGame(x,1,15);

a=[3,5,7,10,12,15,19];
for i=1:length(a)
    thr(i)=MinMaxGame(z,1,a(i));
end
sit=0;

j=1;
for i=1:length(z)
 if(z(i)>=8&&z(i)<10)
  sit=sit+1;
 end
 
end
if(sit>length(z)*90/100)
    j=10;
    disp('SITTING  !!!!!!');
end
sta=0;
for i=1:length(y)
 if(y(i)>=8&&y(i)<10)
  sta=sta+1;
 end
 
end
if(sta>length(y)*9/10)
    j=10;
    disp('STANDING  !!!!!!');
end



e=1;
if(var(x)>15&&var(y)>50&&var(z)>30)
    e=15;j=10;
    disp('RUNNING....');

end

s=0;
for i=1:length(z)
  b(i)=sqrt(x(i)*x(i)+y(i)*y(i)+z(i)*z(i));
  if b(i)>15
      s=s+1;
  end
end
if s>length(z)/7&&e==1
    j=10;
    disp('walking');
end
figure
subplot(2,1,1);
plot(b);k=0;
N=20;n=length(z);
f=0;
% for i=N:length(z)
%     
%    
%   d(i)=abs(x(i))+abs(y(i))+abs(z(i));
%   if d(i)>30
%   f=f+1;
%   end
% end
% 
% subplot(2,1,2);
% plot(d);
g=MinMaxGame(x,0,-5);h=MinMaxGame(y,1,13)
if g>length(z)/10&&j==1&&var(x)>8.5
    disp('climbing up');
elseif h>length(z)/8&&j==1
            disp('climbing down');

    
end
TimeBnPeaks(y,15)
