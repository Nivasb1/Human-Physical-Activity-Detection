function [c]=run(x,y,z)
c=10;


%if ((mean(x)+mean(y))<4.5&&mean(z)>8.5) 
% if (var(x)>15&&var(y)>50&&var(z)>30)
if var(x)+var(y)+var(z)>80
     c=1;
%end

end
end