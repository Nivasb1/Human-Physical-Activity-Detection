function [k]=sma(x,y,z)
sma=zeros(1,length(x));
for i=1:length(x)
    sma(i)=abs(x(i))+abs(y(i))+abs(z(i));
    
end
 k=mean(sma);
end
