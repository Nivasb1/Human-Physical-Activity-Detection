function [v]=smv(x,y,z)
smv=zeros(1,length(x));
for i=1:length(x)
    smv(i)=sqrt(x(i)*x(i)+y(i)*y(i)+z(i)*z(i));
end
v=mean(smv);

end
