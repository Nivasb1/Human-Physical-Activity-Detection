function [f] =walking(x,y,z)

f=0;
s=0;
for i=1:length(z)
    b(i)=sqrt(x(i)*x(i)+y(i)*y(i)+z(i)*z(i));
       if b(i)>15
         s=s+1;
       end
end
   if s>length(z)/7
%        &&TimeBnPeaks(y,14)>5
        f=1;
   end
    
end