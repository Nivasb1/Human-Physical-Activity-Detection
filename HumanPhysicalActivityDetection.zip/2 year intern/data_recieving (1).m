  instrreset
  clear
  clc
%Creating UDP object
  UDPComIn=udp('192.168.16.3','LocalPort',12345);
  set(UDPComIn,'DatagramTerminateMode','off')

  fopen(UDPComIn);

  data=fscanf(UDPComIn);
  disp(data)

  fclose(UDPComIn);

  delete(UDPComIn)