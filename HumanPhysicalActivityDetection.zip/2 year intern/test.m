fileID = fopen('up2.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x=C{1};y=C{2};z=C{3};
% x=x(200:1200);
 %y=y(200:1200);
 %z=z(200:1200);
figure;

% title('Sitting Action');
subplot(3,1,1);
plot(x,'r');
grid on ;axis tight;
xlabel('Time');
ylabel('Accelerometer x Reading');
subplot(3,1,2);
plot(y,'g');
grid on ;axis tight;
xlabel('Time');
ylabel('Accelerometer y Reading');
subplot(3,1,3);
plot(z,'b');
grid on ;axis tight;
xlabel('Time');
ylabel('Accelerometer z Reading');
thr_xmax=MinMaxGame(x,1,15);

a=[3,5,7,10,12,15,19];
for i=1:length(a)
    thr(i)=MinMaxGame(z,1,a(i));
end

 e=1;
  while 1
      a=Sit(x,y,z);
      if a==1
          disp('Sitting')
          break;
      end
      b=Stand(x,y,z);
      if b==1
          disp('Standing')
          break;
      end
       r=run(x,y,z);
      if r==1
          e=15;
          disp('running')
          break;
      end
      
     v=walking(x,y,z);
      if v==1&&e==1
          disp('walking');
          break;
      end
     q=climbingup(x,y,z);
     if q==1
         disp('Climbing Up');
         break;
     end
      p=climbingdown(x,y,z);
     if p==1
         disp('Climbing down');
         break;
     end
     
      disp('noaction')
      break;
  end
  k=1;
  for j=1:15:length(z)-40
  variance(k)=var(y(j:j+40));
  time(k)=TimeBnPeaks(y(j:j+40),15);
  SMA(k)=sma(x(j:j+40),y(j:j+40),z(j:j+40));
  SMV(k)=smv(x(j:j+40),y(j:j+40),z(j:j+40));
k=k+1;
  end

x=1:64;
figure;
scatter(x,variance,'r');hold on;axis tight;


scatter(x,time,'g');hold on;axis tight;
scatter(x,SMA,'y');hold on;axis tight;
scatter(x,SMV,'b');hold on;axis tight;