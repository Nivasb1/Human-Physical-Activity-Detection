function [p]=climbingdown(x,y,z)
p=0;
if TimeBnPeaks(y,15)<20&&TimeBnPeaks(y,15)>5
    p=1;
end


end