clear all
fileID = fopen('down1.txt');

C = textscan(fileID,' %f %f %f','delimiter',',');
fclose(fileID);
% celldisp(C);
x=C{1};y=C{2};z=C{3};
for i=1:length(x);
p(i)=sqrt(x(i)*x(i)+y(i)*y(i)+z(i)*z(i));
end

figure
plot(p);