function [q]=climbingup(x,y,z)
q=0;
if TimeBnPeaks(y,15)>20
    q=1;
end


end