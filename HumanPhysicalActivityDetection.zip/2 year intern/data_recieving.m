  instrreset
  clear
  clc
%Creating UDP object
  UDPComIn=udp('192.168.137.155','LocalPort',12345);
  set(UDPComIn,'DatagramTerminateMode','off')

  fopen(UDPComIn);
while(1)
  data=fscanf(UDPComIn);
  disp(data)
end

  fclose(UDPComIn);

  