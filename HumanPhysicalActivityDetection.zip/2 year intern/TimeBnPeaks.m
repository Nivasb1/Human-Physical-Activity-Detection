function [t]=TimeBnPeaks(y,threshold)
[y1,n]=findpeaks(y);
k=1;
t=0;

for i=1:length(y1)
    if y1(i)>threshold
        a(k)=n(i);
        
        k=k+1;
    end
end
if k>2
for i=1:k-2
    d(i)=a(i+1)-a(i);
end
t=mean(d);
end
end