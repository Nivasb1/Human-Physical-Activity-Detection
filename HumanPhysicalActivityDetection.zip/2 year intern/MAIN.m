instrreset
  clear all
  clc
%Creating UDP object
  UDPComIn=udp('192.168.114.101','LocalPort',12345);
  set(UDPComIn,'DatagramTerminateMode','off')
  
  while 1
  fopen(UDPComIn);
  k=150;
  x=zeros(1,k);y=zeros(1,k);z=zeros(1,k);
  i=1;
  for i=1:k
  data=fscanf(UDPComIn);
%   disp(data)
  
%   fclose(UDPComIn);
%   delete(UDPComIn)
%   fileID = fopen('data.csv');
  C = textscan(data,'%s %f %f %f %f %f','Delimiter',',');
  x(i)=-C{4};y(i)=-C{5};z(i)=-C{6};
  end
  e=1;
  while 1
      a=Sit(x,y,z);
      if a==1
          disp('Sitting')
          break;
      end
      b=Stand(x,y,z);
      if b==1
          disp('Standing')
          break;
      end
     
       r=run(x,y,z);
      if r==1
          e=15;
          disp('running')
          break;
      end
      
     v=walking(x,y,z);
      if v==1&&e==1
          disp('walking');
          break;
      end
     q=climbingup(x,y,z);
     if q==1
         disp('Climbing Up');
         break;
     end
      p=climbingdown(x,y,z);
     if p==1
         disp('Climbing down');
         break;
    
      end
      disp('noaction')
      break;
  end
  fclose(UDPComIn);
  end